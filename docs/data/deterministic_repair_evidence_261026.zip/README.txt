Compact deterministic-repair evidence. Includes the retained failed validation attempt.
Original inputs, PDB predictions, full coordinate arrays and per-residue identity lists remain local.
All current main/dev defaults remain unchanged. Full report/source on the component branch.
