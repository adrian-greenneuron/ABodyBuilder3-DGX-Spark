65 complete pipeline jobs; protocols, commands, telemetry, batch reports and test/controller logs.
No biological input CSVs, PDBs, complete atom arrays, per-residue geometry lists or checkpoints.
Input identities are recorded by SHA-256 and aggregate counts. Main and dev defaults remain unchanged.
