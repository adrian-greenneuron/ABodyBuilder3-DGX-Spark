"""Isolated ahead-of-time adapter; never installed on main or dev.

Preserves checkpoint weights and all eight learned structure updates. The
wrapper exposes tensor inputs to export and retains the existing inference
shortcuts and broadcast point-attention reduction.
"""
from contextlib import contextmanager

import torch


@contextmanager
def symbolic_shape_identities():
    """Bypass only memoization of the original identity-tensor functions.

    Their LRU keys cannot hash SymInt dimensions. Use the exact undecorated
    functions while exporting, then restore all process-local bindings.
    This does not replace any quaternion/rotation arithmetic.
    """
    from abodybuilder3.openfold.utils import rigid_utils
    names = ('identity_rot_mats', 'identity_trans', 'identity_quats')
    original = {name:getattr(rigid_utils,name) for name in names}
    try:
        for name, function in original.items():
            setattr(rigid_utils,name,function.__wrapped__)
        yield
    finally:
        for name, function in original.items():
            setattr(rigid_utils,name,function)


class ModelExportWrapper(torch.nn.Module):
    def __init__(self, model):
        super().__init__()
        self.model = model

    def forward(self, single, pair, aatype, mask):
        return self.model(
            {'single': single, 'pair': pair}, aatype, mask,
            _inference_pair_projected=True,
            _inference_final_only=True,
            _inference_pair_buffer=True,
        )
